import 'dart:async';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class Recipe extends StatefulWidget {
  @override
  _RecipeState createState() => _RecipeState();
}

class _RecipeState extends State<Recipe> {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Food Recipe'),
        centerTitle: true,
        backgroundColor: Color(0xFF263238),
      ),
      body: WebView(
        initialUrl: 'https://www.food.com/topic/healthy',
        
        javascriptMode: JavascriptMode.unrestricted,
        onWebViewCreated: (WebViewController webViewController) {
          _controller.complete(webViewController);
        },
      ),
      floatingActionButton: FutureBuilder<WebViewController>(
        
        future: _controller.future,
        builder: (BuildContext context,
            AsyncSnapshot<WebViewController> controller) {
          if (controller.hasData) {
            return FloatingActionButton(
                child: Icon(Icons.arrow_back),
                backgroundColor: Color(0xFF263238),
                onPressed: () {
                  controller.data.goBack();
                });
          }
          return Container();
        },
      ),
    );
  }
}
