import 'dart:async';

import 'package:flutter/material.dart';
import 'package:http/http.dart' show get;
import 'dart:convert';

import 'alertdialog/dialog_helper.dart';

class Spacecraft {
  final String id;
  final String name, imageUrl, description, calorie;

  Spacecraft(
      {this.id,
      this.name,
      this.imageUrl,
      this.description,
    
      this.calorie});

  factory Spacecraft.fromJson(Map<String, dynamic> jsonData) {
    return Spacecraft(
      id: jsonData['id'],
      name: jsonData['name'],
      description: jsonData['description'],
      imageUrl:
          "http://10.0.2.2/PHP/spacecraft/images/" + jsonData['image_url'],
      
      calorie: jsonData['calorie'],
    );
  }
}

class CustomListView extends StatelessWidget {
  final List<Spacecraft> spacecrafts;

  CustomListView(this.spacecrafts);

  Widget build(context) {
    
    return ListView.builder(
      itemCount: spacecrafts.length,
      itemBuilder: (context, int currentIndex) {
        return createViewItem(spacecrafts[currentIndex], context);
      },
    );
  }

  Widget createViewItem(Spacecraft spacecraft, BuildContext context) {
    return new ListTile(
      title: Container(
       
        child: new Card(
          color: Colors.black54,
          elevation: 15.0,
          child: new Container(
            
            decoration: BoxDecoration(border: Border.all(color: Colors.black)),
            padding: EdgeInsets.all(5.0),
            margin: EdgeInsets.all(2.0),
            
            child: Container(
              
              width: double.infinity,
              
              child: Column(
                children: <Widget>[  
                  GestureDetector(
                  
                    child: Image.network(spacecraft.imageUrl, width: double.infinity, height: 150.0,),

                  ),
                  Row(children: <Widget>[
                    
                    Padding(
                        child: Text(
                          spacecraft.name,
                          style: new TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                          textAlign: TextAlign.right,
                        ),
                        padding: EdgeInsets.all(0.0)),
                    Text(" || ", style: TextStyle(color: Colors.greenAccent),),
                    Padding(
                        child: Text(
                          spacecraft.calorie,
                          style: new TextStyle(fontStyle: FontStyle.italic, color: Colors.yellowAccent),
                          textAlign: TextAlign.right,
                        ),
                        padding: EdgeInsets.all(1.0)),
                  ]),
                ],
              ),
            ),
          ),
        ),
      ),
     onTap: () {
        //We start by creating a Page Route.
        //A MaterialPageRoute is a modal route that replaces the entire
        //screen with a platform-adaptive transition.
        var route = new MaterialPageRoute(
          builder: (BuildContext context) =>
              new SecondScreen(value: spacecraft),
        );
        //A Navigator is a widget that manages a set of child widgets with
        //stack discipline.It allows us navigate pages.
        Navigator.of(context).push(route);
      },
    );
  }
}

//Future is n object representing a delayed computation.
Future<List<Spacecraft>> downloadJSON() async {
  final jsonEndpoint = "http://10.0.2.2/PHP/spacecraft/index2.php";

  final response = await get(jsonEndpoint);

  if (response.statusCode == 200) {
    List spacecrafts = json.decode(response.body);
    return spacecrafts
        .map((spacecraft) => new Spacecraft.fromJson(spacecraft))
        .toList();
  } else
    throw Exception('We were not able to successfully download the json data.');
}

class SecondScreen extends StatefulWidget {
  final Spacecraft value;

  SecondScreen({Key key, this.value}) : super(key: key);

  @override
  _SecondScreenState createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: Text('Details'),
        backgroundColor: Colors.black,
        centerTitle: true,
      ),
      body: new Container(
        color: Color.fromRGBO(38, 50, 56, 1),
        height: double.infinity,
        child: new Center(
          child: ListView(
            children: <Widget>[
              Padding(
                child: new Text(
                  'Food : ${widget.value.name}',
                  style: new TextStyle(fontWeight: FontWeight.bold, color: Colors.tealAccent),
                  textAlign: TextAlign.center,
                ),
                padding: EdgeInsets.all(10.0),
              ),
              Padding(
                //`widget` is the current configuration. A State object's configuration
                //is the corresponding StatefulWidget instance.
                child: Image.network('${widget.value.imageUrl}'),
                padding: EdgeInsets.all(10.0),
              ),
              
                
              Padding(
                child: new Text(
                  'DESCRIPTION : ${widget.value.description}',
                  style: new TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                  textAlign: TextAlign.start,
                ),
                padding: EdgeInsets.all(10.0),
              ),
              

            ],
          ),
        ),
      ),
    );
  }
}

class FoodCalorie extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    
    return new MaterialApp( debugShowCheckedModeBanner: false,
      theme: new ThemeData(
        primarySwatch: Colors.deepOrange,
      ),
      home: new Scaffold(
        appBar: AppBar(
        title: Text('Food Calorie'),
        backgroundColor: Color.fromRGBO(38, 50, 56, 30),
        centerTitle: true,
      ),
        body: Container(
          color: Color.fromRGBO(38, 50, 56, 1),
          child:Center(
          
          //FutureBuilder is a widget that builds itself based on the latest snapshot
          // of interaction with a Future.
          child: new FutureBuilder<List<Spacecraft>>(
            future: downloadJSON(),
            //we pass a BuildContext and an AsyncSnapshot object which is an
            //Immutable representation of the most recent interaction with
            //an asynchronous computation.
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                List<Spacecraft> spacecrafts = snapshot.data;
                return new CustomListView(spacecrafts);
              } else if (snapshot.hasError) {
                return Text('${snapshot.error}');
              }
              //return  a circular progress indicator.
              return new CircularProgressIndicator();
            },
          ),
        ),
        ),
        
      ),
    );
  }
}


