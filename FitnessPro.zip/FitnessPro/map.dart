import 'dart:async';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class Gym extends StatefulWidget {
  @override
  _GymState createState() => _GymState();
}

class _GymState extends State<Gym> {
  final Completer<WebViewController> _controller =
      Completer<WebViewController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gym Location'),
        centerTitle: true,
        backgroundColor: Color(0xFF263238),
      ),
      body: WebView(
        initialUrl: 'https://www.google.com/maps/place/gym+hall/@27.6913684,85.2951781,19z/data=!4m13!1m7!3m6!1s0x39eb1868199f2d47:0xf48b0ab8d867e77a!2sKuleshwor,+Kathmandu+44600!3b1!8m2!3d27.6899521!4d85.2955242!3m4!1s0x39eb18431e6681b5:0xff42ae28118d19af!8m2!3d27.691123!4d85.2956562',
        javascriptMode: JavascriptMode.unrestricted,
        onWebViewCreated: (WebViewController webViewController) {
          _controller.complete(webViewController);
        },
      ),
      floatingActionButton: FutureBuilder<WebViewController>(
        
        future: _controller.future,
        builder: (BuildContext context,
            AsyncSnapshot<WebViewController> controller) {
          if (controller.hasData) {
            return FloatingActionButton(
                child: Icon(Icons.arrow_back),
                backgroundColor: Color(0xFF263238),
                onPressed: () {
                  controller.data.goBack();
                });
          }
          return Container();
        },
      ),
    );
  }
}
