import 'dart:async';

import 'package:flutter/material.dart';
import 'package:http/http.dart' show get;
import 'dart:convert';

import 'alertdialog/dialog_helper.dart';

class Spacecraft {
  final String id;
  final String name, imageUrl, description, stock, contact;

  Spacecraft(
      {this.id,
      this.name,
      this.imageUrl,
      this.description,
      this.stock,
      this.contact});

  factory Spacecraft.fromJson(Map<String, dynamic> jsonData) {
    return Spacecraft(
      id: jsonData['id'],
      name: jsonData['name'],
      description: jsonData['description'],
      imageUrl:
          "http://10.0.2.2/PHP/spacecrafts/images/" + jsonData['image_url'],
      stock: jsonData['stock'],
      contact: jsonData['contact'],
    );
  }
}

class CustomListView extends StatelessWidget {
  final List<Spacecraft> spacecrafts;

  CustomListView(this.spacecrafts);

  Widget build(context) {
    
    return ListView.builder(
      itemCount: spacecrafts.length,
      itemBuilder: (context, int currentIndex) {
        return createViewItem(spacecrafts[currentIndex], context);
      },
    );
  }

  Widget createViewItem(Spacecraft spacecraft, BuildContext context) {
    return new ListTile(
      title: Container(
       
        child: new Card(
          color: Colors.black,
          elevation: 15.0,
          child: new Container(
            
            decoration: BoxDecoration(border: Border.all(color: Colors.black)),
            padding: EdgeInsets.all(5.0),
            margin: EdgeInsets.all(2.0),
            
            child: Container(
              
              width: double.infinity,
              
              child: Column(
                children: <Widget>[  
                  GestureDetector(
                  
                    child: Image.network(spacecraft.imageUrl, width: double.infinity, height: 150.0,),

                  ),
                  Row(children: <Widget>[
                    
                    Padding(
                        child: Text(
                          spacecraft.name,
                          style: new TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                          textAlign: TextAlign.right,
                        ),
                        padding: EdgeInsets.all(0.0)),
                    Text(" || ", style: TextStyle(color: Colors.greenAccent),),
                    Padding(
                        child: Text(
                          spacecraft.stock,
                          style: new TextStyle(fontStyle: FontStyle.italic, color: Colors.yellowAccent),
                          textAlign: TextAlign.right,
                          
                        ),
                        padding: EdgeInsets.all(1.0)),
                  ]),
                ],
              ),
            ),
          ),
        ),
      ),
       onTap: () {
        //We start by creating a Page Route.
        //A MaterialPageRoute is a modal route that replaces the entire
        //screen with a platform-adaptive transition.
        var route = new MaterialPageRoute(
          builder: (BuildContext context) =>
              new SecondScreen(value: spacecraft),
        );
        //A Navigator is a widget that manages a set of child widgets with
        //stack discipline.It allows us navigate pages.
        Navigator.of(context).push(route);
      },
      
    );
  }
}

//Future is n object representing a delayed computation.
Future<List<Spacecraft>> downloadJSON() async {
  final jsonEndpoint = "http://10.0.2.2/PHP/spacecrafts";

  final response = await get(jsonEndpoint);

  if (response.statusCode == 200) {
    List spacecrafts = json.decode(response.body);
    return spacecrafts
        .map((spacecraft) => new Spacecraft.fromJson(spacecraft))
        .toList();
  } else
    throw Exception('We were not able to successfully download the json data.');
}

class SecondScreen extends StatefulWidget {
  final Spacecraft value;

  SecondScreen({Key key, this.value}) : super(key: key);

  @override
  _SecondScreenState createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16)
      ),
      elevation: 10.0,
      backgroundColor: Colors.transparent,
      child: _buildChild(context),
    );
  }

  _buildChild(BuildContext context) => Container(
    height: 500,
    decoration: BoxDecoration(
      color: Colors.redAccent,
      shape: BoxShape.rectangle,
      borderRadius: BorderRadius.all(Radius.circular(12))
    ),
    child: Column(
      children: <Widget>[
        Container(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Image.asset('assets/sad.png', height: 120, width: 120,),
          ),
          width: double.infinity,
          decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.rectangle,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12))
          ),
        ),
        SizedBox(height: 24,),
        Padding(
                child: new Text(
                  'Description : ${widget.value.description}',
                  style: new TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                  textAlign: TextAlign.left,
                ),
                padding: EdgeInsets.all(10.0),
              ),
        SizedBox(height: 8,),
        Padding(
                child: new Text(
                  'Contact : ${widget.value.contact}',
                  style: new TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
                  textAlign: TextAlign.left,
                ),
                padding: EdgeInsets.all(10.0),
              ),
        
      ],
    ),
  );
}




class DisplayPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    
    return new MaterialApp( debugShowCheckedModeBanner: false,
      theme: new ThemeData(
        primarySwatch: Colors.deepOrange,
      ),
      home: new Scaffold(
        appBar: AppBar(
        title: Text('Home Delivery'),
        backgroundColor: Color.fromRGBO(38, 50, 56, 30),
        centerTitle: true,
      ),
        body: Container(
          color: Color.fromRGBO(38, 50, 56, 1),
          child:Center(
          
          //FutureBuilder is a widget that builds itself based on the latest snapshot
          // of interaction with a Future.
          child: new FutureBuilder<List<Spacecraft>>(
            future: downloadJSON(),
            //we pass a BuildContext and an AsyncSnapshot object which is an
            //Immutable representation of the most recent interaction with
            //an asynchronous computation.
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                List<Spacecraft> spacecrafts = snapshot.data;
                return new CustomListView(spacecrafts);
              } else if (snapshot.hasError) {
                return Text('${snapshot.error}');
              }
              //return  a circular progress indicator.
              return new CircularProgressIndicator();
            },
          ),
        ),
        ),
        
      ),
    );
  }
}


