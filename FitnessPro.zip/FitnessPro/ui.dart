import 'package:flutter/material.dart';

class UI extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('WorkOut'),
        centerTitle: true,
      ),
      body: Container(
        color: Color.fromRGBO(38, 50, 56, 1),
        child: ListView(
          children: <Widget>[
            new Padding(
              padding: new EdgeInsets.symmetric(vertical: 0.0, horizontal: 1.0),
              child: new Card(
                color: Color.fromRGBO(38, 50, 56, 1),
                child: new Column(
                  children: <Widget>[
                  
                    GestureDetector(
                      child: Container(
                        
                          width: double.infinity,
                          height: 200.0,
                          decoration: BoxDecoration(
                          
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(20.0),
                            
                            image: DecorationImage(
                                image: AssetImage("assets/abs.jpg"),
                                fit: BoxFit.cover),
                            
                            // button text
                          )),
                      onTap: () {
                        print("you clicked my");
                      },
                    ),
                    Divider(),
                    GestureDetector(
                      child: Container(
                        
                          width: double.infinity,
                          height: 200.0,
                          decoration: BoxDecoration(
                          
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(20.0),
                            
                            image: DecorationImage(
                                image: AssetImage("assets/arms.jpg"),
                                fit: BoxFit.cover),
                            
                            // button text
                          )),
                      onTap: () {
                        print("you clicked my");
                      },
                    ),
                    Divider(),
                    GestureDetector(
                      child: Container(
                        
                          width: double.infinity,
                          height: 200.0,
                          decoration: BoxDecoration(
                          
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(20.0),
                            
                            image: DecorationImage(
                                image: AssetImage("assets/chest.jpg"),
                                fit: BoxFit.cover),
                            
                            // button text
                          )),
                      onTap: () {
                        print("you clicked my");
                      },
                    ),
                    Divider(),
                    GestureDetector(
                      child: Container(
                        
                          width: double.infinity,
                          height: 200.0,
                          decoration: BoxDecoration(
                          
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(20.0),
                            
                            image: DecorationImage(
                                image: AssetImage("assets/legs.jpg"),
                                fit: BoxFit.cover),
                            
                            // button text
                          )),
                      onTap: () {
                        print("you clicked my");
                      },
                    ),
                    Divider(),
                    GestureDetector(
                      child: Container(
                        
                          width: double.infinity,
                          height: 200.0,
                          decoration: BoxDecoration(
                          
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(20.0),
                            
                            image: DecorationImage(
                                image: AssetImage("assets/shoulders.jpg"),
                                fit: BoxFit.cover),
                            
                            // button text
                          )),
                      onTap: () {
                        print("you clicked my");
                      },
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
